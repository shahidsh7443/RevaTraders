jQuery(document).ready(function(e) {
    jQuery('.accordion-section-title').eq(0).after('<span style="position:relative; left:10px; top:1px; padding:2px; background-color:#efc62c; color:#ffffff; font-weight:bold; line-height:22px;">Check Appearance > Theme Options for Pro Settings</span>');
	jQuery('.accordion-section-title').eq(0).css('padding-bottom','15px', 'padding-top','15px');
});