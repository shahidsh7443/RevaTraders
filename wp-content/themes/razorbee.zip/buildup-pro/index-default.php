<style>body, .contact-form-section .address,  .accordion-box .acc-content{color:#575756;}body{font-family:PT Sans; font-size:14px;}.logo h1 {font-family:Oswald;color:#FFFFFF;font-size:33px}.tagline{color:#FFFFFF;}.logo img{height:55px;}.sitenav ul li:hover > ul{background-color:#282828;}.sitenav ul li ul li{border-color:#333333;}.sitenav ul{font-family:'Oswald', sans-serif;font-size:16px}.sitenav ul li a{color:#FFFFFF;}h2.section_title{ font-family:Roboto Condensed; font-size:30px; color:#282828; }h2.section_title::after{ background-color:#282828; }a:hover, .slide_toggle a:hover{color:#272727;}.footer h5{color:#ffffff; font-size:20px;  border-color:#312d2e; }.copyright-txt{color:#ffffff}.design-by{color:#ffffff}.header-top{background-color:#171819; color:#ffffff;}.header{background-color:rgba(16,17,18,0.5);}.themefeatures .one_third .fa{ color:#272727;}.themefeatures .one_third:hover .fa{ color:#ffffff;}.header-top .social-icons a{ color:#a3a9ab;}.button, #commentform input#submit, input.search-submit, .post-password-form input[type=submit], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], #sidebar .search-form input.search-submit{color:#ffffff; }.button:hover, #commentform input#submit:hover, input.search-submit:hover, .post-password-form input[type=submit]:hover, p.read-more a:hover, .pagination ul li .current, .pagination ul li a:hover,.headertop .right a:hover, .wpcf7 form input[type='submit']:hover{background-color:#202020; color:#ffffff;}a.morebutton{background-color:1; color:#ffffff; }a.morebutton:hover{background-color:#202020; color:#ffffff;}a.buttonstyle1{background-color:#202020; color:#ffffff; }a.buttonstyle1:hover{background-color:1; color:#ffffff;}aside.widget, #sidebar .search-form input.search-field{ background-color:#F0EFEF; color:#6e6d6d;  }#footer-wrapper{background-color:#131313; color:#d1d0d0;}#footer-wrapper{background: url(<?php echo get_template_directory_uri(); ?>/images/footer-bg.jpg) no-repeat fixed 100% 100%;}.contactdetail a{color:#d1d0d0; }.copyright-wrapper{background-color:#131313;}.nivo-controlNav a{background-color:#ffffff}.nivo-controlNav a{border-color:#ffffff}#sidebar ul li{border-color:#d0cfcf}#sidebar ul li a{color:#78797c; }.nivo-caption h2{ font-family:Oswald; color:#ffffff; font-size:37px;}.nivo-caption p{font-family:Roboto Condensed; color:#ffffff; font-size:17px;}.copyright-wrapper a:hover{ color: #ffffff; }h1,h2,h3,h4,h5,h6{ font-family:Roboto Condensed; }h1{ font-size:30px; color:#272727;}h2{ font-size:28px; color:#272727;}h3{ font-size:18px; color:#272727;}h4{ font-size:22px; color:#272727;}h5{font-size:18px; color:#272727;}h6{ font-size:16px; color:#272727;}.footer .social-icons a{ color:#c1c0c0; border-color:#c1c0c0;}.nivo-directionNav a{background-color:rgba(0,0,0,0.7);}ul.portfoliofilter li a{ color:#010101;}.holderwrap h5{ color:#ffffff; }figure.effect-bubba figcaption::before, figure.effect-bubba figcaption::after{ border-color:#ffffff; }.news-box h5{ color:#262626; }.news{ background:#ffffff; }.news:after{ border-right-color:#ffffff; }.rightside .news:after{ border-left-color:#ffffff; }.fourbox{ background-color:#f8f8f8; color:#4c4c4c; }.fourbox h6{ color:#282828; }.pagemore{ background-color:#404040; color:#ffffff; }.fourbox:hover .pagemore{ background-color:#ffffff; color:#ffffff; }.team_column, .teammember-content h5{color:#404040;}.teammember-content a{color:#404040;}.member-social-icon a{color:#727171 !important; background-color:#ffffff !important;}.team_column{background:#f3f3f3;}.team_column:hover .teammember-content span, .team_column:hover .teammember-content h5, .team_column:hover p{color:#ffffff;}.owl-controls .owl-dot{ background-color:#494949; }#clienttestiminials .item, #clienttestiminials span{ color:#898989;}.arrow_box{ background:#ffffff;}.arrow_box{ border-color:#dcdcdc;}.arrow_box:after{ border-top-color:#ffffff;}.arrow_box:before{ border-top-color:#dcdcdc;}#clienttestiminials h6 a, #clienttestiminials h6{ color:#010103; }.skill-bg{ background-color:#E0DFDF; }ul.recent-post li a{ color:#ffffff; }.counterlist h6{ color:#262626; }.counterlist .counter{ color:#383838; }.counter::after{ background-color:#383838; }.whychooseusbox:hover .whychooseus-title h6, .whychooseusbox:hover .whychooseus-description{ color:#ffffff; }.whychooseusbox .whychooseus-description{ color:#888888; }.whychooseusbox{ background-color:#ffffff; }.themefeatures .one_third:hover, .button, #commentform input#submit, input.search-submit, 		.post-password-form input[type='submit'], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], #sidebar .search-form input.search-submit, .nivo-controlNav a.active,	.fourbox:hover .pagemore, .counterlist:hover .cntimage,	.counterlist:hover .cntbutton, .offer-1-column .offimgbx, 	.hvr-rectangle-out::before, .vacation-wrap,	.home-post-comment, .toggle a, .holderwrap, .owl-controls .owl-dot.active, h3.widget-title, .box2, .button, #commentform input#submit, 		input.search-submit, .post-password-form input[type=submit], p.read-more a, .pagination ul li span, .pagination ul li a, .headertop .right a, .wpcf7 form input[type='submit'], 		#sidebar .search-form input.search-submit, .team_column:hover, .nivo-controlNav a.active, h1.entry-title:after, a.morebutton, .whychooseusbox:hover{ background-color:#efc62c; }.themefeatures .one_half:hover{background-color:rgba(239,198,44,0.7);}.sitenav ul li a:hover, .sitenav ul li.current_page_item a, .sitenav ul li.current_page_item ul li a:hover, 			.sitenav ul li:hover,.header-top .social-icons a:hover, .social-icons a:hover, .cntbutton, .offcontnt .pricedv,	.fourbox:hover h6,	.vacation-wrap a.bookatour, h2.section_title span, .sitenav ul li a:hover, .sitenav ul li.current_page_item a, .sitenav ul li.current_page_item ul li a:hover, .sitenav ul li:hover, .contactdetail a:hover, .footer h5 span, .footer ul li a:hover, .footer ul li.current_page_item a, div.recent-post a:hover, a, .slide_toggle a, #sidebar ul li a:hover, .copyright-wrapper a, .footer .social-icons a:hover, .counterlist, .sitenav ul li a:hover, .sitenav ul li.current_page_item a, .sitenav ul li.current-menu-parent a.parent, .themefeatures .one_half .fa,.member-social-icon a:hover, 		ul.portfoliofilter li:hover a, ul.portfoliofilter li a.selected{ color:#efc62c; }.team_column:hover .teamrectangle{ border-bottom-color:#efc62c ; }.footer .social-icons a:hover, .whychooseusborder, .counterlist .counter-cen{ border-color:#efc62c ; }.rightside:hover .news::after{ border-left-color:#efc62c ; }.news-box.rightside:hover .news::after{ border-right:none !important; }.news-box:hover .news::after{ border-right-color:#efc62c ; }</style>		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
	</head>

<body id="top" class="home blog logged-in">
<div class="sitewrapper ">

<div class="header-top">
  <div class="container">
        <div class="left"><i class="fa fa-phone"></i> +11 123 456 7890 <span class="phno"><a href="mailto:info@sitename.com"><i class="fa fa-envelope"></i>info@sitename.com</a></span></div>
     <div class="right"> <div class="social-icons"> <a href="#" target="_blank" class="fa fa-facebook" title="facebook"></a> <a href="#" target="_blank" class="fa fa-twitter" title="twitter"></a> <a href="#" target="_blank" class="fa fa-google-plus" title="google-plus"></a> <a href="#" target="_blank" class="fa fa-linkedin" title="linkedin"></a> <a href="#" target="_blank" class="fa fa-rss" title="rss"></a> <a href="#" target="_blank" class="fa fa-youtube" title="youtube"></a></div></div>
     <div class="clear"></div>
      </div>
 </div><!--end header-top-->

<div class="header">
	<div class="container">
      <div class="logo"><div class="site-branding-text"> <a href="<?php echo home_url(); ?>"><h1>Build Up</h1></a>
                  <span class="tagline">Construction WordPress theme</span>
               </div> 
              </div><!-- .logo -->                 
    <div class="header_right">  
     		<div class="toggle">
    	<a class="toggleMenu" href="#">Menu</a>
    </div><!-- toggle -->
    <div class="sitenav"> <ul>
    <li class="current_page_item"><a href="<?php echo home_url(); ?>">Home</a></li>
    <li><a href="#">Sample Page</a></li>
    <li><a href="#">Blog</a></li>
    <li><a href="#">Contact Us</a></li>
</ul></div>   
    </div><!--.sitenav --> 
    </div><!--header_right-->
 <div class="clear"></div>
</div><!-- .container-->

</div><!-- .header -->
    <div class="slider-main">
                       <div id="slider" class="nivoSlider">
                <img src="<?php echo get_template_directory_uri(); ?>/images/slides/slider1.jpg" alt="" title="#slidecaption1"/></div> 
                                     <div id="slidecaption1" class="nivo-html-caption">
                   
                                                  
                        <a href="#"><h2>Build Up WordPress Theme</h2></a>						
                                                                          
                             <p>This is an example page. Its different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors.</p>
                         						                        
                                                     <a class="button" href="#">							
                               READ MORE                             </a>
                          
                    </div>            
    </div><!-- slider -->
    

<section id="welcomearea" >
    <div class="container">  
        <div class="welcomebx">
             
        
<div class="one_half"> <div class="whothumbbx"><img src="<?php echo get_template_directory_uri(); ?>/images/whoweare.jpg" /></div></div>   
<div class="one_half last_column">
<h2 class="section_title">Who We <span>Are</span> </h2>           
 <div class="subtitle" style="font-size:20px; color:#282828; margin:0 0 20px 0;">WELCOME TO DARNA CONSTRUCTIONS</div> <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
Why do we use it?</p>                
<div class="custombtn" style="text-align:center">	
	   <a class="morebutton" href="#" target"">OUR HISTORY</a>	   	   
	</div></div>   
<div class="clear"></div>

		        </div>  
    </div><!-- .container -->
</section><!-- #welcomearea -->
                    
<section id="pagearea">
  <div class="container"> 
		            <div class="fourbox ">
             
            <div class="thumbbx"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon1.jpg" alt="" /></a></div>
             <div class="pagecontent">
             <a href="#"><h6>CONCRETE TRANSPORT</h3></a>             
             <p>Build Up theme is Clean Coded and User friendly customizer options developed it perfectly suitable for WordPress Users.</p> 
                            <a class="pagemore" href="#">READ MORE</a>      
			              </div>
         	</div>
			            <div class="fourbox ">
             
            <div class="thumbbx"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon2.jpg" alt="" /></a></div>
             <div class="pagecontent">
             <a href="#"><h6>ARCHITECTURE</h3></a>             
             <p>Build Up theme is Clean Coded and User friendly customizer options developed it perfectly suitable for WordPress Users.</p> 
                            <a class="pagemore" href="#">READ MORE</a>      
			              </div>
         	</div>
			            <div class="fourbox ">
             
            <div class="thumbbx"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon3.jpg" alt="" /></a></div>
             <div class="pagecontent">
             <a href="#"><h6>ENGINEERING TEAM</h3></a>             
             <p>Build Up theme is Clean Coded and User friendly customizer options developed it perfectly suitable for WordPress Users.</p> 
                            <a class="pagemore" href="#">READ MORE</a>      
			              </div>
         	</div>
			            <div class="fourbox last_column">
             
            <div class="thumbbx"><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon4.jpg" alt="" /></a></div>
             <div class="pagecontent">
             <a href="#"><h6>CONSTRUCTION</h3></a>             
             <p>Build Up theme is Clean Coded and User friendly customizer options developed it perfectly suitable for WordPress Users.</p> 
                            <a class="pagemore" href="#">READ MORE</a>      
			              </div>
         	</div>
			  
        <div class="clear"></div>
    </div><!-- .container -->
</section><!-- #pagearea -->

    

            <section style="background-color:#f5f4f4; " id="" class="">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Why Choose Us</h2>
                                        <p>
<div class="whychooseusbox">
	<a href="#">
		<div class="whychooseusborder">
		<div class="whychooseus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/choose-icon1.png"></div>
			<div class="whychooseustitledes">
			<div class="whychooseus-title"><h6>HEALTHCARE BUILDINGS</h6></div>
			<div class="whychooseus-description">Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque pena tibus et magnis dis parturient mon tes,nascetur.</div>	
			</div>
		</div>
	</a>
</div>
		
<div class="whychooseusbox">
	<a href="#">
		<div class="whychooseusborder">
		<div class="whychooseus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/choose-icon2.png"></div>
			<div class="whychooseustitledes">
			<div class="whychooseus-title"><h6>EDUCATION BUILDINGS</h6></div>
			<div class="whychooseus-description">Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque pena tibus et magnis dis parturient mon tes,nascetur.</div>	
			</div>
		</div>
	</a>
</div>
		
<div class="whychooseusbox">
	<a href="#">
		<div class="whychooseusborder">
		<div class="whychooseus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/choose-icon3.png"></div>
			<div class="whychooseustitledes">
			<div class="whychooseus-title"><h6>GOVERNMENT BUILDINGS</h6></div>
			<div class="whychooseus-description">Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque pena tibus et magnis dis parturient mon tes,nascetur.</div>	
			</div>
		</div>
	</a>
</div>
		
<div class="whychooseusbox">
	<a href="#">
		<div class="whychooseusborder">
		<div class="whychooseus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/choose-icon4.png"></div>
			<div class="whychooseustitledes">
			<div class="whychooseus-title"><h6>PARKING LOTS</h6></div>
			<div class="whychooseus-description">Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque pena tibus et magnis dis parturient mon tes,nascetur.</div>	
			</div>
		</div>
	</a>
</div>
		
<div class="whychooseusbox">
	<a href="#">
		<div class="whychooseusborder">
		<div class="whychooseus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/choose-icon1.png"></div>
			<div class="whychooseustitledes">
			<div class="whychooseus-title"><h6>DOMESTIC BUILDINGS</h6></div>
			<div class="whychooseus-description">Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque pena tibus et magnis dis parturient mon tes,nascetur.</div>	
			</div>
		</div>
	</a>
</div>
		
<div class="whychooseusbox">
	<a href="#">
		<div class="whychooseusborder">
		<div class="whychooseus-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/choose-icon5.png"></div>
			<div class="whychooseustitledes">
			<div class="whychooseus-title"><h6>GREEN CONSTRUCTION</h6></div>
			<div class="whychooseus-description">Phasellus porta. Fusce suscipit varius mi. Cum sociis natoque pena tibus et magnis dis parturient mon tes,nascetur.</div>	
			</div>
		</div>
	</a>
</div>
		</p>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; background-image:url(<?php echo get_template_directory_uri(); ?>/images/certifications.png); background-repeat:no-repeat; background-position: center top; background-attachment:fixed; background-size:cover; " id="" class="">
            	<div class="container">
                    <div class="">
                                            <p>
		<div class="counterlist">
			<div class="counter-cen">
			<i class="fa fa-trophy"></i>	
			<div class="counter">53</div>
			</div>
			<h6>AWAED WININGS</h6>	   	   
		</div>
		
		<div class="counterlist">
			<div class="counter-cen">
			<i class="fa fa-black-tie"></i>	
			<div class="counter">1818</div>
			</div>
			<h6>TOTAL PROJECTS</h6>	   	   
		</div>
		
		<div class="counterlist">
			<div class="counter-cen">
			<i class="fa fa-university"></i>	
			<div class="counter">523</div>
			</div>
			<h6>GOV.PROJECTS</h6>	   	   
		</div>
		
		<div class="counterlist">
			<div class="counter-cen">
			<i class="fa fa-heart"></i>	
			<div class="counter">1499</div>
			</div>
			<h6>SATISFIED CLIENTS</h6>	   	   
		</div>
		</p>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; " id="featureservices" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Our Features</h2>
                                        <p>
			 <div class="servicesbox" style="background:#ba950b" >
				<div class="services-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon-1.png"/></div>
				<div class="services-title"><h4 style="color:#ffffff">Building Innovation</h4></div>
				<div class="services-description" style="color:#ffffff">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
			 </div>
		
			 <div class="servicesbox" style="background:#cea40b" >
				<div class="services-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon-2.png"/></div>
				<div class="services-title"><h4 style="color:#ffffff">Project Management</h4></div>
				<div class="services-description" style="color:#ffffff">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
			 </div>
		
			 <div class="servicesbox" style="background:#ba950b" >
				<div class="services-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon-3.png"/></div>
				<div class="services-title"><h4 style="color:#ffffff">Inspection & Testing</h4></div>
				<div class="services-description" style="color:#ffffff">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
			 </div>
		
			 <div class="servicesbox" style="background:#a88500" >
				<div class="services-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/services-icon-4.png"/></div>
				<div class="services-title"><h4 style="color:#ffffff">New Technologies</h4></div>
				<div class="services-description" style="color:#ffffff">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</div>
			 </div>
		</p>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; " id="recentproject" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Recent Project</h2>
                                        <div class="recentproject">
<div class="subtitle" style="font-size:18px; color:#282828; margin:0 0 50px 0;">It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Why do we use it?</div>
</div>
<div class="recentproject_list">
			<div class="item">
				<a href="#" target="_blank"><div class="pro-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery-1.jpg" /></div></a>
				
			</div>
		
		
			<div class="item">
				<a href="#" target="_blank"><div class="pro-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery-2.jpg" /></div></a>
				
			</div>
		
		
			<div class="item">
				<a href="#" target="_blank"><div class="pro-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery-3.jpg" /></div></a>
				
			</div>
		
		
			<div class="item">
				<a href="#" target="_blank"><div class="pro-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery-4.jpg" /></div></a>
				
			</div>
		
		
			<div class="item">
				<a href="#" target="_blank"><div class="pro-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery-5.jpg" /></div></a>
				
			</div>
		
		
			<div class="item">
				<a href="#" target="_blank"><div class="pro-thumb"><img src="<?php echo get_template_directory_uri(); ?>/images/gallery-6.jpg" /></div></a>
				
			</div>
		
		</div>
<div class="custombtn" style="text-align:center">	
	   <a class="morebutton" href="#" target"">VIEW ALL PROJECT</a>	   	   
	</div>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#f5f4f4; " id="latestposts" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Latest News</h2>
                                        
			<div class="news-box  ">
				<div class="news-thumb ">
					<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt="" /></a>
				</div>
				<div class="news">
					<h5>Markup: HTML Tags and Formatting</h5>
					<p>Headings Header one Header two Header three Header four Header five Header six Blockquotes Single line blockquote: Stay hungry. Stay foolish. Multi line blockquote with a cite reference: People think...</p>
					<div class="view-all-btn"><a href="#">Read More</a></div>
				</div>
			</div>
			<div class="news-box rightside">
				<div class="news-thumb ">
					<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt="" /></a>
				</div>
				<div class="news">
					<h5>Markup: Image Alignment</h5>
					<p>Welcome to image alignment! The best way to demonstrate the ebb and flow of the various image positioning options is to nestle them snuggly among an ocean of words. Grab...</p>
					<div class="view-all-btn"><a href="#">Read More</a></div>
				</div>
			</div><div class="clear"></div>
			<div class="news-box  ">
				<div class="news-thumb ">
					<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt="" /></a>
				</div>
				<div class="news">
					<h5>Markup: Text Alignment</h5>
					<p>Default This is a paragraph. It should not have any alignment of any kind. It should just flow like you would normally expect. Nothing fancy. Just straight up text, free...</p>
					<div class="view-all-btn"><a href="#">Read More</a></div>
				</div>
			</div>
			<div class="news-box rightside">
				<div class="news-thumb ">
					<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" alt="" /></a>
				</div>
				<div class="news">
					<h5>Markup: Title With Special Characters</h5>
					<p>Putting special characters in the title should have no adverse effect on the layout or functionality. Special characters in the post title have been known to cause issues with JavaScript...</p>
					<div class="view-all-btn"><a href="#">Read More</a></div>
				</div>
			</div><div class="clear"></div>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; background-image:url(<?php echo get_template_directory_uri(); ?>/images/bytheme.jpg); background-repeat:no-repeat; background-position: center top; background-attachment:fixed; background-size:cover; " id="bytheme" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Trusted By Over 7200+ Customers</h2>
                                        <div class="bytheme">
<div class="subtitle" style="font-size:25px; color:#ffffff; margin:0 0 20px 0;">We are happy to server our customers and support them. Join Us Now</div><div class="subtitle" style="font-size:18px; color:#ffffff; margin:0 0 50px 0;">It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. Why do we use it?</div><div class="custombtn" style="text-align:center">	
	   <a class="morebutton" href="#" target"">BUY NOW</a>	   	   
	</div>
</div>
<div class="clear"></div>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; " id="ourteamsection" class="menu_page">
            	<div class="container">
                    <div class="teamwrapper">
                                                <h2 class="section_title">Meet Our Team</h2>
                                        <p><div class="section-teammember"><div class="team_column">
			<div class="ourteam-thumb"><a href="#" title="Mark"><img src="<?php echo get_template_directory_uri(); ?>/images/team1.jpg" alt=" " /></a></div>
			
				<div class="teammember-content">
				<a href="#" title="Mark"><h5>Mark</h5></a>
				<span class="member-designation">You Designation</span>
				 
				 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took</p>
				 <div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="skype" target="_blank"><i class="fa fa-skype fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div><div class="clear"></div></div></div><div class="team_column">
			<div class="ourteam-thumb"><a href="#" title="Sara"><img src="<?php echo get_template_directory_uri(); ?>/images/team2.jpg" alt=" " /></a></div>
			
				<div class="teammember-content">
				
				<a href="#" title="Sara"><h5>Sara</h5></a>
				<span class="member-designation">Best Support</span>
				 
				 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took</p>
				 <div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="skype" target="_blank"><i class="fa fa-skype fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div><div class="clear"></div></div></div><div class="team_column">
			<div class="ourteam-thumb"><a href="#" title="John Doe"><img src="<?php echo get_template_directory_uri(); ?>/images/team3.jpg" alt=" " /></a></div>
			
				<div class="teammember-content">
				
				<a href="#" title="John Doe"><h5>John Doe</h5></a>
				<span class="member-designation">You Designation</span>
				 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took</p>
				 <div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="skype" target="_blank"><i class="fa fa-skype fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div><div class="clear"></div></div></div><div class="team_column">
			<div class="ourteam-thumb"><a href="#" title="Alena"><img src="<?php echo get_template_directory_uri(); ?>/images/team4.jpg" alt=" " /></a></div>
			
				<div class="teammember-content">
				
				<a href="#" title="Alena"><h5>Alena</h5></a>
				<span class="member-designation">Project Maneger</span>
				 
				 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took</p>
				 <div class="member-social-icon"><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook fa-lg"></i></a><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter fa-lg"></i></a><a href="#" title="skype" target="_blank"><i class="fa fa-skype fa-lg"></i></a><a href="#" title="youtube" target="_blank"><i class="fa fa-youtube fa-lg"></i></a></div><div class="clear"></div></div></div><div class="clear"></div></div><div class="clear"></div></p>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#f5f4f4; " id="testimonialswhy" class="menu_page">
            	<div class="container">
                    <div class="">
                                            <div class="one_half"></p>
<h2 class="section_title">Our Testimonials</h2>
<p><div class="subtitle" style="font-size:17px; color:#282828; margin:0 0 20px 0;">Knowledge is knowledge whether it teaches you Build Up of destruction</div><div id="clienttestiminials"><div class="owl-carousel">
				 <div class="item">
				 <div class="arrow_box">
				  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#8217;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type&#8230;</p>

					</div><div class="clear"></div>
					<div class="left">
					<h6>Max</h6>	
					 <span>Web Developer</span>
					 </div>
					 <div class="right">
						 <div class="tmthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/team1.jpg" alt=" " /></div>
					 </div>
				</div>
				 <div class="item">
				 <div class="arrow_box">
				  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#8217;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type&#8230;</p>

					</div><div class="clear"></div>
					<div class="left">
					<h6>Alena</h6>	
					 <span></span>
					 </div>
					 <div class="right">
						 <div class="tmthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/team2.jpg" alt=" " /></div>
					 </div>
				</div>
				 <div class="item">
				 <div class="arrow_box">
				  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#8217;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type&#8230;</p>

					</div><div class="clear"></div>
					<div class="left">
					<h6>John Doe</h6>	
					 <span>Best Support</span>
					 </div>
					 <div class="right">
						 <div class="tmthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/team3.jpg" alt=" " /></div>
					 </div>
				</div>
				 <div class="item">
				 <div class="arrow_box">
				  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#8217;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type&#8230;</p>

					</div><div class="clear"></div>
					<div class="left">
					<h6>Mark</h6>	
					 <span>Best Support</span>
					 </div>
					 <div class="right">
						 <div class="tmthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/team4.jpg" alt=" " /></div>
					 </div>
				</div></div></div><br />
</div>
<div class="one_half last_column"></p>
<h2 class="section_title">Why <span>Us?</span></h2>
<p><div class="subtitle" style="font-size:17px; color:#282828; margin:0 0 20px 0;">Becquse we are very flexible</div><div class="skillbar clearfix " data-percent="90%">
			<div class="skillbar-title"><span>Coding</span></div>
			<div class="skill-bg"><div class="skillbar-bar" style="background:#efc62c"></div></div>
			<div class="skill-bar-percent">90%</div>
			</div><div class="skillbar clearfix " data-percent="70%">
			<div class="skillbar-title"><span>Design</span></div>
			<div class="skill-bg"><div class="skillbar-bar" style="background:#efc62c"></div></div>
			<div class="skill-bar-percent">70%</div>
			</div><div class="skillbar clearfix " data-percent="55%">
			<div class="skillbar-title"><span>Building</span></div>
			<div class="skill-bg"><div class="skillbar-bar" style="background:#efc62c"></div></div>
			<div class="skill-bar-percent">55%</div>
			</div><div class="skillbar clearfix " data-percent="100%">
			<div class="skillbar-title"><span>SEO</span></div>
			<div class="skill-bg"><div class="skillbar-bar" style="background:#efc62c"></div></div>
			<div class="skill-bar-percent">100%</div>
			</div></div>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; " id="ourgallery" class="menu_page">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Our Works</h2>
                                        <div class="photobooth"><div class="row fourcol portfoliowrap"><div class="portfolio"><div class="entry branding">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-1.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-1.jpg" alt=" " />
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry editoral">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-2.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-2.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry print">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-3.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-3.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry webdesign">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-4.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-4.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry print">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-5.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-5.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry editoral">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-6.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-6.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry branding">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-7.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-7.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div><div class="entry webdesign">
						<div class="holderwrap">
							<a href="<?php echo get_template_directory_uri(); ?>/images/gallery-8.jpg" data-rel="prettyPhoto[bkpGallery]">
								<figure class="effect-bubba">						
								<img src="<?php echo get_template_directory_uri(); ?>/images/gallery-8.jpg"/>
								<h5>Title here</h5>
								<figcaption></figcaption>
								</figure>
							</a>
						</div>
					</div></div></div></div>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
                        <section style="background-color:#ffffff; " id="" class="">
            	<div class="container">
                    <div class="">
                                                <h2 class="section_title">Our Clients</h2>
                                        <ul id="flexiselDemo3"><li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/client-logo1.jpg" /></a></li><li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/client-logo2.jpg" /></a></li><li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/client-logo3.jpg" /></a></li><li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/client-logo4.jpg" /></a></li><li><a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/client-logo5.jpg" /></a></li></ul>
                     </div><!-- .end section class -->  
                     <div class="clear"></div>                 
                 </div><!-- container -->
            </section>
        
            
<div id="footer-wrapper">
    	<div class="container footer">      
        
<!-- =============================== Column One - 1 =================================== -->
			
<!-- =============================== Column Fourth - 4 =================================== -->
          
    		<div class="cols-4">    
                  
                <div class="widget-column-1">            	
              <h5>About us</h5>
                <p>Donec ut ex ac nulla pellentesque mollis in a enim Suspendisse suscipit velit id ultricies auctor. Duis turpis arcu, aliquet sed sollicitudin seduisque velit nibh.</br> </br>Donec ut ex ac nulla sapien mauris, vitae sodales tellus suspendisse suscipit velit id ultricies auctor.</p>                  
                <div class="clear"></div> 
              </div>                  
			           
                             	 <div class="widget-column-2">                
            	<h5>Main Navigation</h5>
<ul><li class="current_page_item"><a href="<?php echo home_url(); ?>">Home</a></li>
<li><a href="#">Sample Page</a></li>
<li><a href="#">Blog</a></li>
<li><a href="#">Contact Us</a></li>
</ul>
                </div>
            	                
                          <div class="widget-column-3">     
            	
                	 <h5>Recent Posts</h5>
                   <ul class="recent-post"> 
                	                                      	
                    <li>
                    <a href="#">
                                        <div class="footerthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" width="70"  /></div>
                    </a> 
                    <strong><a href="#">Markup: HTML Tags and Formatting</a></strong>                   
                    <p>Headings Header one Header&#8230;</p>
					
                    </li>
                                      	
                    <li>
                    <a href="#"><div class="footerthumb"><img src="<?php echo get_template_directory_uri(); ?>/images/img_404.png" width="70"  /></div>
					</a> 
                    <strong><a href="#">Markup: Image Alignment</a></strong>                   
                    <p>Welcome to image alignment!&#8230;</p>
                    </li>
                                        </ul>
                            	

               </div>
                        
            
             
              <div class="widget-column-4">
                
                <h5>Contact Info</h5>
                  <div class="contactdetail">
                	                	  <p> lorem ipsum Donec ultricies mattis nulla, suscipit risus tristique ut.</p>
                    	
               
					                        <p><i class="fa fa-phone"></i>+91 987 654 3210</p>
                                         
					                      <p><i class="fa fa-envelope"></i><a href="mailto:info@sitename.com">info@sitename.com</a></p>
                                       
                                                            
                </div>
                
                <div class="social-icons">
			<a href="#" target="_blank" class="fa fa-facebook" title="facebook"></a>
			<a href="#" target="_blank" class="fa fa-twitter" title="twitter"></a>
			<a href="#" target="_blank" class="fa fa-linkedin" title="linkedin"></a>
			<a href="#" target="_blank" class="fa fa-google-plus" title="google-plus"></a>				
		</div>
		   
                
                          
              </div>             
                            
                    <div class="clear"></div>
                </div><!--end .cols-4-->
               
            <div class="clear"></div>
        
        </div><!--end .container-->
     
        <div class="copyright-wrapper">
        	<div class="container">
            	<div class="copyright-txt">
					<div class="left"> Copyright &copy; 2017. All rights reserved</div>
                    <div class="right"><span>Design by <a href="https://www.gracethemes.com/" target="_blank">Grace Themes</a></span></div>
                </div>
           		<div class="clear"></div>
            </div> 
       </div>
       
    </div>    
<div id="back-top">
		<a title="Top of Page" href="#top"><span></span></a>
	</div>
	</div>
</body>
</html>

